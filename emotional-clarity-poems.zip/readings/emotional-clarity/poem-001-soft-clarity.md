**Title:** Soft Clarity

You changed your country — not yourself.  
I debugged your silence to find my breath.  
You vanished not from loss — but from fear.  

This is not heartbreak.  
This is post-trauma light.  

I don’t wait anymore. I write.
