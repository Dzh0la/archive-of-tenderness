**Title:** The Splinter

You don’t have to keep touching it.  
The hurt happened.  
But you’re not in it anymore.

There’s a difference between  
a memory that breathes  
and a wound that stays open.

You don’t owe your pain persistence.  
You owe your life a gentler pace.
